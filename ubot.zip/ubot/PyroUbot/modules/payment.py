import asyncio
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pytz import timezone
from PyroUbot import *

CONFIRM_PAYMENT = []

@PY.CALLBACK("confirm")
async def _(client, callback_query):
    user_id = callback_query.from_user.id
    full_name = f"<b>{callback_query.from_user.first_name} {callback_query.from_user.last_name or ''}</b>"
    
    # 1. AMBIL DATA ROLE & DURASI DARI CALLBACK
    data = callback_query.data.split()
    role = data[1] if len(data) > 1 else "member"
    durasi = data[2] if len(data) > 2 else "1" # "1" sebulan, "0" perma

    # 2. KAMUS HARGA (FONT TEBAL SESUAI LIST KAMU)
    prices = {
        "member": {"1": "𝟭𝗞", "0": "𝟮𝗞"},
        "seles": {"1": "𝟯𝗞", "0": "𝟱𝗞"},
        "admin": {"1": "𝟳𝗞", "0": "𝟭𝟬𝗞"},
        "owner": {"1": "𝟭𝟯𝗞", "0": "𝟭𝟱𝗞"},
        "tk": {"1": "𝟭𝟳𝗞", "0": "𝟮𝟬𝗞"},
        "ceo": {"1": "𝟮𝟮𝗞", "0": "𝟮𝟱𝗞"},
        "founder": {"1": "𝟯𝟮𝗞", "0": "𝟯𝟱𝗞"},
    }

    harga = prices.get(role, {}).get(durasi, "𝗛𝘂𝗯𝘂𝗻𝗴𝗶 𝗔𝗱𝗺𝗶𝗻")
    teks_durasi = "𝟭 𝗕𝘂𝗹𝗮𝗻" if durasi == "1" else "𝗣𝗲𝗿𝗺𝗮𝗻𝗲𝗻"

    if user_id in CONFIRM_PAYMENT:
        CONFIRM_PAYMENT.remove(user_id)
    CONFIRM_PAYMENT.append(user_id)

    await callback_query.message.delete()

    # 🔥 KIRIM INSTRUKSI PEMBAYARAN
    await bot.send_photo(
        user_id,
        photo="https://files.catbox.moe/f92qip.jpg",
        caption=f"""
<blockquote><b>💬 𝗦𝗜𝗟𝗔𝗛𝗞𝗔𝗡 𝗠𝗘𝗟𝗔𝗞𝗨𝗞𝗔𝗡 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡

🎟️ 𝗛𝗔𝗥𝗚𝗔 : {harga}
🏷️ 𝗥𝗢𝗟𝗘 : {role.upper()}
⏳ 𝗗𝗨𝗥𝗔𝗦𝗜 : {teks_durasi}
💳 𝗗𝗔𝗡𝗔 : <code>087711851477</code>

💬 𝗞𝗶𝗿𝗶𝗺 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁 𝗕𝘂𝗸𝘁𝗶 𝗧𝗿𝗮𝗻𝘀𝗳𝗲𝗿 Untuk Konfirmasi:
{full_name}</b></blockquote>
""",
    )

    try:
        # Menunggu kiriman dari user (Timeout 5 Menit)
        pesan = await bot.listen(user_id, timeout=300)
    except asyncio.TimeoutError:
        if user_id in CONFIRM_PAYMENT:
            CONFIRM_PAYMENT.remove(user_id)
        return await bot.send_message(user_id, "<b>❌ 𝗣𝗘𝗠𝗕𝗔𝗧𝗔𝗟𝗔𝗡 𝗢𝗧𝗢𝗠𝗔𝗧𝗜𝗦 (𝗧𝗜𝗠𝗘𝗢𝗨𝗧)</b>")

    if user_id in CONFIRM_PAYMENT:
        # 🔍 DETEKSI BUKAN FOTO
        if not pesan.photo:
            CONFIRM_PAYMENT.remove(user_id)
            buttons = [[InlineKeyboardButton("✅ 𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜 𝗨𝗟𝗔𝗡𝗚", callback_data=f"confirm {role} {durasi}")]]
            return await bot.send_message(
                user_id, 
                "<b>❌ 𝗠𝗢𝗛𝗢𝗡 𝗠𝗔𝗔𝗙, 𝗛𝗔𝗥𝗔𝗣 𝗞𝗜𝗥𝗜𝗠𝗞𝗔𝗡 𝗕𝗨𝗞𝗧𝗜 𝗗𝗔𝗟𝗔𝗠 𝗕𝗘𝗡𝗧𝗨𝗞 𝗙𝗢𝗧𝗢 (𝗦𝗖𝗥𝗘𝗘𝗡𝗦𝗛𝗢𝗧) ❗\n\n𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗞𝗹𝗶𝗸 𝗧𝗼𝗺𝗯𝗼𝗹 𝗗𝗶 𝗕𝗮𝘄𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗻𝗰𝗼𝗯𝗮 𝗟𝗮𝗴𝗶.</b>",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        
        # ✅ JIKA KIRIM FOTO BENAR
        else:
            buttons = [
                [InlineKeyboardButton("✅ 𝗧𝗘𝗥𝗜𝗠𝗔", callback_data=f"success {user_id} {role} {durasi}")],
                [InlineKeyboardButton("❌ 𝗧𝗢𝗟𝗔𝗞", callback_data=f"failed {user_id}")]
            ]

            await pesan.copy(
                OWNER_ID,
                caption=f"<blockquote><b>🔔 𝗟𝗔𝗣𝗢𝗥𝗔𝗡 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡\n\n👤 𝗨𝘀𝗲𝗿: {full_name}\n🆔 𝗜𝗗: <code>{user_id}</code>\n💎 𝗥𝗼𝗹𝗲: {role.upper()}\n🗓️ 𝗗𝘂𝗿𝗮𝘀𝗶: {teks_durasi}</b></blockquote>",
                reply_markup=InlineKeyboardMarkup(buttons),
            )

            CONFIRM_PAYMENT.remove(user_id)
            return await bot.send_message(
                user_id, 
                f"<blockquote><b>💬 𝗕𝗔𝗜𝗞 {full_name}\n\n🏦 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗦𝗘𝗗𝗔𝗡𝗚 𝗗𝗜𝗖𝗘𝗞 𝗔𝗗𝗠𝗜𝗡. 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜.</b></blockquote>"
            )

# ==========================================
# SUCCESS / FAILED / HOME
# ==========================================

@PY.CALLBACK("^(success|failed|home)")
async def _(client, callback_query):
    query = callback_query.data.split()
    user_target = int(query[1])
    get_user = await bot.get_users(user_target)

    # ✅ ADMIN KLIK TERIMA
    if query[0] == "success":
        role = query[2]
        durasi = query[3] # "1" = 1 Bulan, "0" = Permanen
        
        # 1. DATABASE ROLE LIST SESUAI HIERARKI
        role_list = ["PREM_USERS", "SELER_USERS", "ADMIN_USERS", "OWNER_USERS", "KHASJIR_USERS", "CIOGWMAH_USERS", "ALLROLE_USERS"]
        rank_idx = {"member": 1, "seles": 2, "admin": 3, "owner": 4, "tk": 5, "ceo": 6, "founder": 7}
        target_rank = rank_idx.get(role, 1)

        # 🚀 BOM DATABASE (OTOMATIS ADD SEMUA ROLE DI BAWAHNYA)
        for i in range(target_rank):
            await add_to_vars(client.me.id, role_list[i], get_user.id)

        # 🗓️ ATUR MASA EXPIRED (FULL TEBAL)
        now = datetime.now(timezone("Asia/Jakarta"))
        if durasi == "1":
            expired = now + relativedelta(months=1)
            await set_expired_date(get_user.id, expired)
            msg_exp = "𝟭 𝗕𝗨𝗟𝗔𝗡"
        else:
            expired = now + relativedelta(years=100)
            await set_expired_date(get_user.id, expired)
            msg_exp = "𝗣𝗘𝗥𝗠𝗔𝗡𝗘𝗡"

        # 🔗 LOGIKA LINK GRUP (MEMBER 1 BULAN TIDAK DAPAT)
        is_member_sebulan = (role == "member" and durasi == "1")
        
        link_grup = (
            "\n\n<b>🔗 𝗦𝗜𝗟𝗔𝗛𝗞𝗔𝗡 𝗝𝗢𝗜𝗡 𝗚𝗥𝗨𝗣 𝗗𝗜 𝗕𝗔𝗪𝗔𝗛 𝗜𝗡𝗜: https://t.me/+GrpsayBLKgs3NGZl</b>\n"
            "<b>💬 𝗞𝗘𝗠𝗨𝗗𝗜𝗔𝗡 𝗦𝗘𝗕𝗨𝗧 𝗥𝗢𝗟𝗘 𝗞𝗔𝗟𝗜𝗔𝗡 𝗗𝗜 𝗗𝗔𝗟𝗔𝗠 𝗚𝗥𝗨𝗣!</b>"
        )
        
        caption_user = (
            f"<blockquote><b>✅ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗗𝗜𝗧𝗘𝗥𝗜𝗠𝗔\n\n"
            f"💎 𝗥𝗢𝗟𝗘: {role.upper()}\n"
            f"🗓️ 𝗗𝗨𝗥𝗔𝗦𝗜: {msg_exp}\n\n"
            f"𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚 𝗔𝗡𝗗𝗔 𝗕𝗜𝗦𝗔 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗨𝗦𝗘𝗥𝗕𝗢𝗧!</b>"
        )
        
        # JIKA BUKAN MEMBER SEBULAN, MAKA KASIH LINK GRUP
        if not is_member_sebulan:
            caption_user += link_grup
        
        caption_user += "</blockquote>"

        # Kirim notifikasi ke User
        await bot.send_message(
            get_user.id,
            caption_user,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🤖 𝗕𝗨𝗔𝗧 𝗨𝗦𝗘𝗥𝗕𝗢𝗧", callback_data="buat_ubot")]]),
        )

        # Update pesan di Admin
        return await callback_query.edit_message_caption(
            caption=f"<blockquote><b>✅ {get_user.first_name} 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 𝗗𝗜𝗝𝗔𝗗𝗜𝗞𝗔𝗡 {role.upper()} ({msg_exp})</b></blockquote>",
        )

    # ❌ ADMIN KLIK TOLAK
    if query[0] == "failed":
        await bot.send_message(
            get_user.id, 
            "<b>❌ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 𝗧𝗜𝗗𝗔𝗞 𝗗𝗜𝗞𝗢𝗡𝗙𝗜𝗥𝗠𝗔𝗦𝗜 / 𝗕𝗨𝗞𝗧𝗜 𝗧𝗜𝗗𝗔𝗞 𝗩𝗔𝗟𝗜𝗗.\n\n𝗦𝗜𝗟𝗔𝗛𝗞𝗔𝗡 𝗕𝗔𝗬𝗔𝗥 𝗨𝗟𝗔𝗡𝗚 𝗗𝗘𝗡𝗚𝗔𝗡 𝗕𝗨𝗞𝗧𝗜 𝗬𝗔𝗡𝗚 𝗕𝗘𝗡𝗔𝗥.</b>"
        )
        return await callback_query.edit_message_caption(caption=f"<b>❌ {get_user.first_name} 𝗗𝗜𝗧𝗢𝗟𝗔𝗞.</b>")

    # 🏠 KEMBALI KE HOME
    if query[0] == "home":
        if get_user.id in CONFIRM_PAYMENT:
            CONFIRM_PAYMENT.remove(get_user.id)
        buttons_home = BTN.START(callback_query)
        return await callback_query.edit_message_text(MSG.START(callback_query), reply_markup=InlineKeyboardMarkup(buttons_home))
        